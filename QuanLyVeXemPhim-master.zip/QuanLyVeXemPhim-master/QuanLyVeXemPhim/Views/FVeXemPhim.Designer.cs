﻿namespace QuanLyVeXemPhim.Views
{
    partial class FVeXemPhim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtTinhTrang = new TextBox();
            label9 = new Label();
            txtIDPhim = new TextBox();
            txtIDThanhVien = new TextBox();
            txtGiaVe = new TextBox();
            txtIDChoNgoi = new TextBox();
            txtIDSuatChieu = new TextBox();
            txtIDVe = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            s = new GroupBox();
            lsvVeXemPhim = new ListView();
            panel1 = new Panel();
            btnThoat = new Button();
            btnCapNhat = new Button();
            btnNhapMoi = new Button();
            btnXoa = new Button();
            btnThem = new Button();
            panel2 = new Panel();
            groupBox4 = new GroupBox();
            txtTimKiem = new TextBox();
            phim = new Label();
            groupBox3 = new GroupBox();
            label7 = new Label();
            txtTongSo = new Button();
            label8 = new Label();
            groupBox1.SuspendLayout();
            s.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtTinhTrang);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(txtIDPhim);
            groupBox1.Controls.Add(txtIDThanhVien);
            groupBox1.Controls.Add(txtGiaVe);
            groupBox1.Controls.Add(txtIDChoNgoi);
            groupBox1.Controls.Add(txtIDSuatChieu);
            groupBox1.Controls.Add(txtIDVe);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(12, 54);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1210, 228);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin vé xem phim";
            // 
            // txtTinhTrang
            // 
            txtTinhTrang.Location = new Point(935, 58);
            txtTinhTrang.Name = "txtTinhTrang";
            txtTinhTrang.Size = new Size(184, 34);
            txtTinhTrang.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F);
            label9.Location = new Point(786, 64);
            label9.Name = "label9";
            label9.Size = new Size(101, 28);
            label9.TabIndex = 17;
            label9.Text = "Tình trạng";
            // 
            // txtIDPhim
            // 
            txtIDPhim.Location = new Point(935, 115);
            txtIDPhim.Name = "txtIDPhim";
            txtIDPhim.Size = new Size(184, 34);
            txtIDPhim.TabIndex = 16;
            // 
            // txtIDThanhVien
            // 
            txtIDThanhVien.Location = new Point(497, 115);
            txtIDThanhVien.Name = "txtIDThanhVien";
            txtIDThanhVien.Size = new Size(184, 34);
            txtIDThanhVien.TabIndex = 15;
            // 
            // txtGiaVe
            // 
            txtGiaVe.Location = new Point(497, 56);
            txtGiaVe.Name = "txtGiaVe";
            txtGiaVe.Size = new Size(184, 34);
            txtGiaVe.TabIndex = 14;
            // 
            // txtIDChoNgoi
            // 
            txtIDChoNgoi.Location = new Point(497, 172);
            txtIDChoNgoi.Name = "txtIDChoNgoi";
            txtIDChoNgoi.Size = new Size(184, 34);
            txtIDChoNgoi.TabIndex = 13;
            // 
            // txtIDSuatChieu
            // 
            txtIDSuatChieu.Location = new Point(160, 115);
            txtIDSuatChieu.Name = "txtIDSuatChieu";
            txtIDSuatChieu.Size = new Size(184, 34);
            txtIDSuatChieu.TabIndex = 12;
            // 
            // txtIDVe
            // 
            txtIDVe.Location = new Point(160, 58);
            txtIDVe.Name = "txtIDVe";
            txtIDVe.Size = new Size(184, 34);
            txtIDVe.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F);
            label6.Location = new Point(788, 121);
            label6.Name = "label6";
            label6.Size = new Size(89, 28);
            label6.TabIndex = 10;
            label6.Text = "Mã Phim";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(348, 121);
            label5.Name = "label5";
            label5.Size = new Size(141, 28);
            label5.TabIndex = 4;
            label5.Text = "Mã Thành Viên";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(348, 70);
            label4.Name = "label4";
            label4.Size = new Size(67, 28);
            label4.TabIndex = 3;
            label4.Text = "Giá Vé";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(348, 178);
            label3.Name = "label3";
            label3.Size = new Size(129, 28);
            label3.TabIndex = 2;
            label3.Text = "Mã Chỗ Ngồi";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(29, 121);
            label2.Name = "label2";
            label2.Size = new Size(135, 28);
            label2.TabIndex = 1;
            label2.Text = "Mã Suất chiếu";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(29, 61);
            label1.Name = "label1";
            label1.Size = new Size(66, 28);
            label1.TabIndex = 0;
            label1.Text = "Mã Vé";
            label1.Click += label1_Click;
            // 
            // s
            // 
            s.Controls.Add(lsvVeXemPhim);
            s.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            s.Location = new Point(12, 309);
            s.Name = "s";
            s.Size = new Size(1210, 228);
            s.TabIndex = 1;
            s.TabStop = false;
            s.Text = "Danh Sách Vé Xem Phim";
            // 
            // lsvVeXemPhim
            // 
            lsvVeXemPhim.Dock = DockStyle.Fill;
            lsvVeXemPhim.Location = new Point(3, 30);
            lsvVeXemPhim.Name = "lsvVeXemPhim";
            lsvVeXemPhim.Size = new Size(1204, 195);
            lsvVeXemPhim.TabIndex = 0;
            lsvVeXemPhim.UseCompatibleStateImageBehavior = false;
            lsvVeXemPhim.SelectedIndexChanged += lsvVeXemPhim_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnThoat);
            panel1.Controls.Add(btnCapNhat);
            panel1.Controls.Add(btnNhapMoi);
            panel1.Controls.Add(btnXoa);
            panel1.Controls.Add(btnThem);
            panel1.Location = new Point(1228, 54);
            panel1.Name = "panel1";
            panel1.Size = new Size(221, 224);
            panel1.TabIndex = 5;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(36, 172);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(154, 32);
            btnThoat.TabIndex = 4;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // btnCapNhat
            // 
            btnCapNhat.Location = new Point(36, 134);
            btnCapNhat.Name = "btnCapNhat";
            btnCapNhat.Size = new Size(154, 32);
            btnCapNhat.TabIndex = 3;
            btnCapNhat.Text = "Cập nhật";
            btnCapNhat.UseVisualStyleBackColor = true;
            btnCapNhat.Click += btnCapNhat_Click;
            // 
            // btnNhapMoi
            // 
            btnNhapMoi.Location = new Point(36, 96);
            btnNhapMoi.Name = "btnNhapMoi";
            btnNhapMoi.Size = new Size(154, 32);
            btnNhapMoi.TabIndex = 2;
            btnNhapMoi.Text = "Nhập mới";
            btnNhapMoi.UseVisualStyleBackColor = true;
            btnNhapMoi.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Location = new Point(36, 58);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(154, 32);
            btnXoa.TabIndex = 1;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnThem
            // 
            btnThem.Location = new Point(36, 20);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(154, 32);
            btnThem.TabIndex = 0;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(groupBox4);
            panel2.Controls.Add(groupBox3);
            panel2.Location = new Point(1228, 284);
            panel2.Name = "panel2";
            panel2.Size = new Size(221, 271);
            panel2.TabIndex = 6;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(txtTimKiem);
            groupBox4.Controls.Add(phim);
            groupBox4.Location = new Point(3, 143);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(215, 125);
            groupBox4.TabIndex = 1;
            groupBox4.TabStop = false;
            groupBox4.Text = "Tìm kiếm";
            // 
            // txtTimKiem
            // 
            txtTimKiem.Location = new Point(16, 76);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(184, 27);
            txtTimKiem.TabIndex = 16;
            txtTimKiem.TextChanged += txtTimKiem_TextChanged;
            // 
            // phim
            // 
            phim.AutoSize = true;
            phim.Location = new Point(58, 36);
            phim.Name = "phim";
            phim.Size = new Size(89, 20);
            phim.TabIndex = 2;
            phim.Text = "Tìm kiếm vé";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(txtTongSo);
            groupBox3.Location = new Point(3, 3);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(215, 125);
            groupBox3.TabIndex = 0;
            groupBox3.TabStop = false;
            groupBox3.Text = "Thống kê";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(58, 36);
            label7.Name = "label7";
            label7.Size = new Size(81, 20);
            label7.TabIndex = 1;
            label7.Text = "Tổng số vé";
            // 
            // txtTongSo
            // 
            txtTongSo.Location = new Point(6, 70);
            txtTongSo.Name = "txtTongSo";
            txtTongSo.Size = new Size(203, 40);
            txtTongSo.TabIndex = 0;
            txtTongSo.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(395, 13);
            label8.Name = "label8";
            label8.Size = new Size(286, 38);
            label8.TabIndex = 7;
            label8.Text = "Quản lý Vé Xem Phim";
            // 
            // FVeXemPhim
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1470, 590);
            Controls.Add(label8);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(s);
            Controls.Add(groupBox1);
            Name = "FVeXemPhim";
            Text = "FVeXemPhim";
            Load += FVeXemPhim_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            s.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox s;
        private Panel panel1;
        private Button btnThoat;
        private Button btnCapNhat;
        private Button btnNhapMoi;
        private Button btnXoa;
        private Button btnThem;
        private Panel panel2;
        private GroupBox groupBox4;
        private Label phim;
        private GroupBox groupBox3;
        private Label label7;
        private Button txtTongSo;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label6;
        private ListView lsvVeXemPhim;
        private Label label8;
        private TextBox txtIDPhim;
        private TextBox txtIDThanhVien;
        private TextBox txtGiaVe;
        private TextBox txtIDChoNgoi;
        private TextBox txtIDSuatChieu;
        private TextBox txtIDVe;
        private TextBox txtTimKiem;
        private TextBox txtTinhTrang;
        private Label label9;
    }
}